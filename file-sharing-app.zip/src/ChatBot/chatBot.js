// const express = require('express');
// const bodyParser = require('body-parser');
// const axios = require('axios');
// const fs = require('fs');
// const path = require('path');

// const app = express();
// app.use(bodyParser.json());

// // Change this line in your chatBot.js
// const packageJsonPath = path.join(__dirname, '..',  '..', 'package.json');  // Going up three directories to reach the root
//  // Changed this line to go up one directory

// // Function to analyze dependencies
// async function analyzeDependencies(packageJsonContent) {
//     try {
//         const dependencies = {
//             ...packageJsonContent.dependencies,
//             ...packageJsonContent.devDependencies
//         };
//         const results = [];

//         for (const [pkg, version] of Object.entries(dependencies)) {
//             const info = await getPackageInfo(pkg, version);
//             results.push(info);
//         }

//         return formatResults(results);
//     } catch (error) {
//         return `Error analyzing dependencies: ${error.message}`;
//     }
// }


// // Function to get package information
// async function getPackageInfo(packageName, version) {
//     try {
//         const response = await axios.get(`https://registry.npmjs.org/${packageName}`);
//         const data = response.data;
//         const cleanVer = version.replace(/[\^~>=<]/g, '');

//         const isDeprecated = data.deprecated || 
//                            Object.values(data.versions).some(v => v.deprecated) ||
//                            (data.versions[cleanVer] && data.versions[cleanVer].deprecated);

//         return {
//             package: packageName,
//             currentVersion: version,
//             latestVersion: data['dist-tags'].latest,
//             deprecated: data.deprecated || 
//                      (data.versions[cleanVer] && data.versions[cleanVer].deprecated) ||
//                      false,
//             deprecationMessage: data.versions[cleanVer]?.deprecated || null,
//             isOutdated: cleanVer !== data['dist-tags'].latest
//         };
//     } catch (error) {
//         return {
//             package: packageName,
//             error: `Error fetching package info: ${error.message}`
//         };
//     }
// }

// function formatResults(results) {
//     let response = "📦 Dependency Analysis Report:\n\n";

//     results.forEach(dep => {
//         if (dep.error) {
//             response += `❌ ${dep.package}: ${dep.error}\n\n`;
//             return;
//         }

//         if (dep.deprecated) {
//             response += `⛔ ${dep.package} is DEPRECATED!\n`;
//             if (dep.deprecationMessage) {
//                 response += `   Message: ${dep.deprecationMessage}\n`;
//             }
//             response += `   Current: ${dep.currentVersion}\n`;
//             response += `   Latest: ${dep.latestVersion}\n\n`;
//         } else if (dep.isOutdated) {
//             response += `⚠️ ${dep.package} is outdated!\n`;
//             response += `   Current: ${dep.currentVersion}\n`;
//             response += `   Latest: ${dep.latestVersion}\n\n`;
//         } else {
//             response += `✅ ${dep.package} is up to date (${dep.currentVersion})\n\n`;
//         }
//     });

//     return response;
// }

// // Chat endpoint
// app.post('/chat', async (req, res) => {
//     const message = req.body.message.toLowerCase();

//     if (message.includes('dependabot') || message.includes('check dependencies')) {
//         try {
//             // Read package.json
//              const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
            
//             // Analyze dependencies
//             const analysis = await analyzeDependencies(packageJson);
            
//             res.json({
//                 response: analysis
//             });
//         } catch (error) {
//             res.json({
//                 response: `Error: ${error.message}`
//             });
//         }
//     } else {
//         res.json({
//             response: "I can help you check package dependencies. Just mention 'dependabot' or 'check dependencies' in your message."
//         });
//     }
// });

// // Simple frontend
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'chat.html'));
// });

// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server running on port ${PORT}`);
// });



// Chatbot.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Chatbot = () => {
    const [messages, setMessages] = useState([]);
    const [inputMessage, setInputMessage] = useState('');
    const [loading, setLoading] = useState(false);
    const [packageJson, setPackageJson] = useState(null);

    // Load package.json when component mounts
    useEffect(() => {
        // Using relative path to fetch package.json
        fetch('/package.json')
            .then(response => response.json())
            .then(data => {
                setPackageJson(data);
            })
            .catch(error => {
                console.error('Error loading package.json:', error);
            });
    }, []);

    const mockNpmService = {
        getPackageInfo: async (packageName) => {
            try {
                // Using npm registry API to get real package data
                const response = await axios.get(`https://registry.npmjs.org/${packageName}`);
                return {
                    'dist-tags': response.data['dist-tags'],
                    deprecated: response.data.deprecated || false
                };
            } catch (error) {
                console.error(`Error fetching ${packageName} info:`, error);
                return {
                    'dist-tags': { latest: '0.0.0' },
                    deprecated: false
                };
            }
        }
    };

    const analyzeDependencies = async () => {
        if (!packageJson) {
            return "Unable to load package.json file.";
        }

        const dependencies = {
            ...packageJson.dependencies,
            ...packageJson.devDependencies
        };
        const results = [];

        for (const [pkg, version] of Object.entries(dependencies)) {
            try {
                const info = await mockNpmService.getPackageInfo(pkg);
                const cleanVer = version.replace(/[\^~>=<]/g, '');
                
                results.push({
                    package: pkg,
                    currentVersion: version,
                    latestVersion: info['dist-tags'].latest,
                    deprecated: info.deprecated || false,
                    isOutdated: cleanVer !== info['dist-tags'].latest,
                    type: packageJson.dependencies[pkg] ? 'dependency' : 'devDependency'
                });
            } catch (error) {
                results.push({
                    package: pkg,
                    error: `Error fetching package info: ${error.message}`
                });
            }
        }

        return formatDetailedResults(results);
    };

    const formatDetailedResults = (results) => {
        let response = "📦 Complete Package Analysis Report:\n\n";
        
        // Separate dependencies and devDependencies
        const deps = results.filter(r => r.type === 'dependency');
        const devDeps = results.filter(r => r.type === 'devDependency');

        response += "🔧 Dependencies:\n";
        response += "================\n";
        deps.forEach(dep => {
            response += formatPackageInfo(dep);
        });

        response += "\n📚 DevDependencies:\n";
        response += "==================\n";
        devDeps.forEach(dep => {
            response += formatPackageInfo(dep);
        });

        // Add summary section
        const outdatedDeps = results.filter(r => r.isOutdated).length;
        const deprecatedDeps = results.filter(r => r.deprecated).length;
        const upToDateDeps = results.filter(r => !r.isOutdated && !r.deprecated).length;

        response += "\n📊 Summary:\n";
        response += "==========\n";
        response += `Total Packages: ${results.length}\n`;
        response += `Up to date: ${upToDateDeps}\n`;
        response += `Outdated: ${outdatedDeps}\n`;
        response += `Deprecated: ${deprecatedDeps}\n`;

        return response;
    };

    const formatPackageInfo = (dep) => {
        if (dep.error) {
            return `❌ ${dep.package}: ${dep.error}\n`;
        }

        let status = dep.isOutdated ? "⚠️ Outdated" : "✅ Up to date";
        if (dep.deprecated) status = "⛔ DEPRECATED";

        return `${dep.package}
    Current: ${dep.currentVersion}
    Latest:  ${dep.latestVersion}
    Status:  ${status}\n\n`;
    };

    const handleSendMessage = async () => {
        if (!inputMessage.trim()) return;

        const userMessage = {
            type: 'user',
            content: inputMessage
        };
        setMessages(prev => [...prev, userMessage]);
        setLoading(true);

        let response;
        if (inputMessage.toLowerCase().includes('dependabot') || 
            inputMessage.toLowerCase().includes('check dependencies') ||
            inputMessage.toLowerCase().includes('packages')) {
            response = await analyzeDependencies();
        } else {
            response = "I can help you check all your package dependencies. Try asking me to:\n" +
                      "- 'check dependencies'\n" +
                      "- 'show all packages'\n" +
                      "- 'analyze dependencies'";
        }

        const botMessage = {
            type: 'bot',
            content: response
        };
        setMessages(prev => [...prev, botMessage]);
        setLoading(false);
        setInputMessage('');
    };

    return (
        <div className="chatbot-container">
            <div className="chat-messages">
                {messages.map((message, index) => (
                    <div key={index} className={`message ${message.type}`}>
                        <pre>{message.content}</pre>
                    </div>
                ))}
                {loading && <div className="message bot">Analyzing all packages...</div>}
            </div>
            <div className="chat-input">
                <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type 'check dependencies' to analyze packages..."
                />
                <button onClick={handleSendMessage}>Send</button>
            </div>
            <style jsx>{`
                .chatbot-container {
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    height: 600px;
                    display: flex;
                    flex-direction: column;
                    background-color: #ffffff;
                }

                .chat-messages {
                    flex-grow: 1;
                    overflow-y: auto;
                    padding: 10px;
                    margin-bottom: 20px;
                }

                .message {
                    margin: 10px 0;
                    padding: 10px;
                    border-radius: 8px;
                    max-width: 90%;
                }

                .message.user {
                    background-color: #e3f2fd;
                    margin-left: auto;
                }

                .message.bot {
                    background-color: #f5f5f5;
                    margin-right: auto;
                    font-family: monospace;
                }

                .message pre {
                    white-space: pre-wrap;
                    word-wrap: break-word;
                    margin: 0;
                    font-family: monospace;
                }

                .chat-input {
                    display: flex;
                    gap: 10px;
                }

                input {
                    flex-grow: 1;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    font-size: 14px;
                }

                button {
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-weight: bold;
                }

                button:hover {
                    background-color: #0056b3;
                }
            `}</style>
        </div>
    );
};

export default Chatbot;

