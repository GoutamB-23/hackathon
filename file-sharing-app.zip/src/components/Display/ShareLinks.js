import React from 'react';
import { Box, Typography } from '@mui/material';
import QRCode from 'react-qr-code';
import { useSpring, animated } from '@react-spring/web';

function ShareLinks({ link, filename }) {
      const fadeProps = useSpring({
    from: { opacity: 0 },
    to: { opacity: 1 },
    delay: 300, // Delay for a smoother entrance
  });

  return (
    <animated.div style={fadeProps}>
    <Box>
      <Typography variant="h6">Download Link:</Typography>
      <Typography variant="body1" gutterBottom>
        {link}
      </Typography>
      <Typography variant="h6" gutterBottom>QR Code:</Typography>
      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        <QRCode value={link} size={200} />
      </Box>
    </Box>
    </animated.div>
  );
}

export default ShareLinks;