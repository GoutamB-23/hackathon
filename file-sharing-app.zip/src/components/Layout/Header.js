// src/components/Layout/Header.js
import React from 'react';
import { Box, Typography } from '@mui/material';
import { keyframes } from '@mui/system';

const fadeIn = keyframes`
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;

const slideIn = keyframes`
  from {
    opacity: 0;
    transform: translateX(-50px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
`;

function Header() {
  return (
    <header id="header-section">
    <Box 
      sx={{ 
        padding: '120px 40px 40px 40px', // Added top padding to account for navbar
        maxWidth: '1200px',
        margin: '0 auto'
      }}
    >
      <Typography 
        variant="h3" 
        component="h1"
        sx={{
          fontWeight: 'bold',
          mb: 4,
          animation: `${fadeIn} 1s ease-out`,
          background: 'linear-gradient(45deg,rgb(97, 94, 105) 30%,rgb(5, 23, 27) 90%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}
      >
        Development & In-house Apps Wireless Installation
      </Typography>

      <Typography 
        variant="h6"
        sx={{
          mb: 4,
          animation: `${slideIn} 1s ease-out`,
          animationDelay: '0.2s',
          opacity: 0,
          animationFillMode: 'forwards',
        }}
      >
        APP Deploy is a tool for developers to deploy Development and In-house applications directly to the devices.
      </Typography>

      <Box sx={{ pl: 2 }}>
        {[
          '1. Upload the iOS or Android application.',
          '2. Send the link to your testers, clients, friends or even use it yourself.',
          '3. Open the link in the browser on the device and click on install.'
        ].map((text, index) => (
          <Typography 
            key={index}
            variant="body1"
            sx={{
              mb: 2,
              animation: `${slideIn} 1s ease-out`,
              animationDelay: `${0.4 + (index * 0.2)}s`,
              opacity: 0,
              animationFillMode: 'forwards',
              '&:hover': {
                transform: 'translateX(10px)',
                color: '#2196F3',
              },
              transition: 'transform 0.3s ease, color 0.3s ease',
              fontSize: '1.1rem',
              display: 'flex',
              alignItems: 'center',
              '&::before': {
                content: '""',
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: '#2196F3',
                marginRight: '12px',
                transform: 'scale(0)',
                animation: `${fadeIn} 0.5s ease-out forwards`,
                animationDelay: `${0.6 + (index * 0.2)}s`,
              }
            }}
          >
            {text}
          </Typography>
        ))}
      </Box>

      <Typography 
        variant="h6"
        sx={{
          mt: 4,
          fontWeight: 'bold',
          animation: `${slideIn} 1s ease-out`,
          animationDelay: '1s',
          opacity: 0,
          animationFillMode: 'forwards',
          color: '#000000'
        }}
      >
        It works for iOS and Android.
      </Typography>
    </Box>
    </header>
  );
}

export default Header;
