// src/components/Layout/Footer.js
import React from 'react';
import { Box, Container, Grid, Typography, Link, IconButton, Paper } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import TwitterIcon from '@mui/icons-material/Twitter';
import './LayOut.css';

function Footer() {
  const theme = useTheme();

  return (
    <footer id="footer-section">
    <Box
      component="footer"
      sx={{
        backgroundColor: theme.palette.mode === 'dark' ? '#1A1A1A' : '#f5f5f5',
        color: theme.palette.text.primary,
        py: 6,
        borderTop: `1px solid ${theme.palette.divider}`,
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4} sx={{ mb: 4 }}>
          {/* Details Block */}
          <Grid item xs={12} md={6} className="footer-block">
            <Paper 
              elevation={3}
              sx={{
                p: 3,
                height: '100%',
                backgroundColor: theme.palette.mode === 'dark' ? '#242424' : '#ffffff',
                transition: 'all 0.3s ease',
              }}
            >
              <Typography variant="h5" gutterBottom sx={{ 
                borderBottom: `2px solid ${theme.palette.primary.main}`,
                pb: 1,
                mb: 3
              }}>
                About Us
              </Typography>
              <Box className="footer-animate">
                <Typography variant="body1" paragraph>
                  Our file sharing application provides a secure and efficient way to share
                  files across devices. With end-to-end encryption and real-time syncing,
                  your data remains safe and accessible whenever you need it.
                </Typography>
                <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>
                  Features:
                </Typography>
                <Box sx={{ pl: 2 }}>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    ⚡ Secure file sharing with end-to-end encryption
                  </Typography>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    🔄 Real-time synchronization across devices
                  </Typography>
                  <Typography component="li" variant="body1" sx={{ mb: 1 }}>
                    💻 Cross-platform compatibility
                  </Typography>
                  <Typography component="li" variant="body1">
                    ☁️ Cloud storage integration
                  </Typography>
                </Box>
              </Box>
            </Paper>
          </Grid>

          {/* Contact Block */}
           <section id="contact-section">
          <Grid item xs={12} md={6} className="footer-block">
            <Paper 
              elevation={3}
              sx={{
                p: 3,
                height: '100%',
                backgroundColor: theme.palette.mode === 'dark' ? '#242424' : '#ffffff',
                transition: 'all 0.3s ease',
              }}
            >
              <Typography variant="h5" gutterBottom sx={{ 
                borderBottom: `2px solid ${theme.palette.primary.main}`,
                pb: 1,
                mb: 3
              }}>
                Contact Us
              </Typography>
              <Box className="footer-animate">
                {/* Contact Details */}
                <Box sx={{ mb: 4 }}>
                  <Box sx={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    mb: 2,
                    '&:hover': {
                      transform: 'translateX(10px)',
                      transition: 'transform 0.3s ease'
                    }
                  }}>
                    <EmailIcon sx={{ mr: 2, color: theme.palette.primary.main }} />
                    <Typography variant="body1">
                      Email: contact@filesharing.com
                    </Typography>
                  </Box>
                  
                  <Box sx={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    mb: 2,
                    '&:hover': {
                      transform: 'translateX(10px)',
                      transition: 'transform 0.3s ease'
                    }
                  }}>
                    <PhoneIcon sx={{ mr: 2, color: theme.palette.primary.main }} />
                    <Typography variant="body1">
                      Phone: +1 (555) 123-4567
                    </Typography>
                  </Box>
                  
                  <Box sx={{ 
                    display: 'flex', 
                    alignItems: 'center',
                    '&:hover': {
                      transform: 'translateX(10px)',
                      transition: 'transform 0.3s ease'
                    }
                  }}>
                    <LocationOnIcon sx={{ mr: 2, color: theme.palette.primary.main }} />
                    <Typography variant="body1">
                      123 File Street, Cloud City, DC 10001
                    </Typography>
                  </Box>
                </Box>

                {/* Social Media Links */}
                <Box>
                  <Typography variant="h6" gutterBottom>
                    Connect With Us
                  </Typography>
                  <Box sx={{ 
                    display: 'flex', 
                    gap: 2,
                    mt: 2 
                  }}>
                    <IconButton 
                      aria-label="LinkedIn"
                      sx={{ 
                        color: theme.palette.primary.main,
                        '&:hover': {
                          transform: 'scale(1.1)',
                          backgroundColor: theme.palette.primary.main,
                          color: 'white'
                        },
                        transition: 'all 0.3s ease'
                      }}
                    >
                      <LinkedInIcon />
                    </IconButton>
                    <IconButton 
                      aria-label="GitHub"
                      sx={{ 
                        color: theme.palette.primary.main,
                        '&:hover': {
                          transform: 'scale(1.1)',
                          backgroundColor: theme.palette.primary.main,
                          color: 'white'
                        },
                        transition: 'all 0.3s ease'
                      }}
                    >
                      <GitHubIcon />
                    </IconButton>
                    <IconButton 
                      aria-label="Twitter"
                      sx={{ 
                        color: theme.palette.primary.main,
                        '&:hover': {
                          transform: 'scale(1.1)',
                          backgroundColor: theme.palette.primary.main,
                          color: 'white'
                        },
                        transition: 'all 0.3s ease'
                      }}
                    >
                      <TwitterIcon />
                    </IconButton>
                  </Box>
                </Box>
              </Box>
            </Paper>
          </Grid>
          </section>
        </Grid>

        {/* Copyright Section */}
        <Box 
          className="footer-animate"
          sx={{ 
            mt: 4, 
            pt: 3, 
            borderTop: `1px solid ${theme.palette.divider}`,
            textAlign: 'center'
          }}
        >
          <Typography variant="body2" color="text.secondary">
            © {new Date().getFullYear()} File Sharing App. All rights reserved.
          </Typography>
          <Box sx={{ mt: 1 }}>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Privacy Policy
            </Link>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Terms of Service
            </Link>
            <Link href="#" color="inherit" sx={{ mx: 2 }}>
              Cookie Policy
            </Link>
          </Box>
        </Box>
      </Container>
    </Box>
    </footer>
  );
}

export default Footer;
