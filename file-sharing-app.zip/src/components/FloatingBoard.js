// import React, { useState } from 'react';
// import { useSpring, animated, useSprings } from '@react-spring/web';
// import { useDrag } from '@use-gesture/react';

// function FloatingBoard({ isOpen, onClose, position }) {
//   const [hoveredButton, setHoveredButton] = useState(null);

//   const buttons = [
//     { icon: '🏠', title: 'Home', color: '#669EF2' },
//     { icon: '📞', title: 'Contact', color: '#F9DB6D' },
//     { icon: 'ℹ️', title: 'About', color: '#DC602E' },
//     { icon: '-', title: 'Close', color: '#83BB70' }
//   ];

//   // Modified animation to align with the icon
//   const buttonAnimations = useSprings(
//     buttons.length,
//     buttons.map((_, index) => ({
//       from: { x: 0, opacity: 0 },
//       to: {
//         x: isOpen ? -(index + 1) * 70 : 0, // Adjusted spacing
//         opacity: isOpen ? 1 : 0
//       },
//       config: { tension: 300, friction: 20 },
//       delay: index * 100
//     }))
//   );

//   const [{ x }, api] = useSpring(() => ({ x: 0 }));

//   const bind = useDrag(({ down, movement: [mx] }) => {
//     api.start({ x: down ? mx : 0, immediate: down });
//   });

//   if (!isOpen) return null;

//   return (
//     <animated.div
//       {...bind()}
//       style={{
//         position: 'fixed',
//         top: '20px',
//         left: `${position.left - 20}px`, // Adjusted left position
//         display: 'flex',
//         alignItems: 'center',
//         zIndex: 9998,
//         touchAction: 'none',
//         transform: x.to(x => `translateX(${x}px)`),
//         height: '56px' // Match button height
//       }}
//     >
//       {buttons.map((button, index) => (
//         <animated.button
//           key={button.title}
//           style={{
//             width: '56px',
//             height: '56px',
//             borderRadius: '50%',
//             border: 'none',
//             backgroundColor: button.color,
//             color: 'white',
//             cursor: 'pointer',
//             display: 'flex',
//             alignItems: 'center',
//             justifyContent: 'center',
//             position: 'absolute',
//             left: 0,
//             transform: buttonAnimations[index].x.to(
//               x => `translateX(${x}px) scale(${hoveredButton === index ? 1.1 : 1})`
//             ),
//             opacity: buttonAnimations[index].opacity,
//             boxShadow: '0 3px 8px rgba(0,0,0,0.2)',
//             transition: 'transform 0.2s ease'
//           }}
//           onMouseEnter={() => setHoveredButton(index)}
//           onMouseLeave={() => setHoveredButton(null)}
//           onClick={() => {
//             if (button.title === 'Close') {
//               onClose();
//             } else {
//               console.log(`${button.title} clicked`);
//             }
//           }}
//         >
//           <span style={{ fontSize: '20px' }}>{button.icon}</span>
//         </animated.button>
//       ))}
//     </animated.div>
//   );
// }

// export default FloatingBoard;


// src/components/FloatingBoard.js
import React, { useState } from 'react';
import { useSpring, animated, useSprings } from '@react-spring/web';
import { useDrag } from '@use-gesture/react';
import { Tooltip } from '@mui/material';

function FloatingBoard({ isOpen, onClose, position }) {
  const [hoveredButton, setHoveredButton] = useState(null);

  const buttons = [
    { icon: '🏠', title: 'Home', color: '#669EF2', tooltip: 'Go to Home Page' },
    { icon: '📞', title: 'Contact', color: '#F9DB6D', tooltip: 'Contact Us' },
    { icon: 'ℹ️', title: 'About', color: '#DC602E', tooltip: 'About Us' },
    // { icon: '-', title: 'Close', color: '#83BB70', tooltip: 'Close Menu' }
  ];

  const buttonAnimations = useSprings(
    buttons.length,
    buttons.map((_, index) => ({
      from: { x: 0, opacity: 0 },
      to: {
        x: isOpen ? -(index + 1) * 70 : 0,
        opacity: isOpen ? 1 : 0
      },
      config: { tension: 300, friction: 20 },
      delay: index * 100
    }))
  );

  const [{ x }, api] = useSpring(() => ({ x: 0 }));

  const bind = useDrag(({ down, movement: [mx] }) => {
    api.start({ x: down ? mx : 0, immediate: down });
  });

  if (!isOpen) return null;

  return (
    <animated.div
      {...bind()}
      style={{
        position: 'fixed',
        top: '20px',
        left: `${position.left - 20}px`,
        display: 'flex',
        alignItems: 'center',
        zIndex: 9998,
        touchAction: 'none',
        transform: x.to(x => `translateX(${x}px)`),
        height: '56px'
      }}
    >
      {buttons.map((button, index) => (
        <Tooltip 
          key={button.title}
          title={button.tooltip}
          placement="bottom"
          arrow
          enterDelay={200}
          leaveDelay={0}
          sx={{
            '& .MuiTooltip-tooltip': {
              backgroundColor: button.color,
              color: '#fff',
              fontSize: '0.875rem',
              padding: '8px 12px',
              borderRadius: '4px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
            },
            '& .MuiTooltip-arrow': {
              color: button.color
            }
          }}
        >
          <animated.button
            style={{
              width: '56px',
              height: '56px',
              borderRadius: '50%',
              border: 'none',
              backgroundColor: button.color,
              color: 'white',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'absolute',
              left: 0,
              transform: buttonAnimations[index].x.to(
                x => `translateX(${x}px) scale(${hoveredButton === index ? 1.1 : 1})`
              ),
              opacity: buttonAnimations[index].opacity,
              boxShadow: '0 3px 8px rgba(0,0,0,0.2)',
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={() => setHoveredButton(index)}
            onMouseLeave={() => setHoveredButton(null)}
            onClick={() => {
              if (button.title === 'Close') {
                onClose();
              } else {
                console.log(`${button.title} clicked`);
              }
            }}
          >
            <span style={{ fontSize: '20px' }}>{button.icon}</span>
          </animated.button>
        </Tooltip>
      ))}
    </animated.div>
  );
}

export default FloatingBoard;
